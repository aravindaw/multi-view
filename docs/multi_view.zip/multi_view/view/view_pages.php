<?php
/**
 * Created by IntelliJ IDEA.
 * User: aravindaweerasekara
 * Date: 11/9/14
 * Time: 9:13 PM
 */

//define('BASE_URL', 'multiviewer.com/');

require_once '../model/model.php';
$page_data = new pageViewer;
$results = $page_data->page_list();
?>

<html>
<head>
  <link type="text/css" rel="stylesheet" href="css/table.css">
  <link href="../../../docs/dist/css/bootstrap-theme.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../../../docs/multi_view/view/css/mainpage.css">
  <link rel="stylesheet" type="text/css" href="../../../docs/multi_view/view/css/mainpage2.css">

  <title>
    view page list
  </title>
  <script type="text/javascript" charset="utf-8">
    function func_delete(id) {
      var del_page = confirm('Do you really need to delete this page..!!');
      if (del_page == true) {
        location.href = "../controller/page.php?action=delete_page&page_id=" + id;

      } else {
        return false;
      }
    }

    function main_page() {
      location.href = "../../../../../"
    }

  </script>
  <style>
    td.center {
      text-align: center;
      width: 100px !important;
    }
  </style>
</head>
<body>
<div class="container theme-showcase" role="main" id="content">
  <h2 style="color: white; font-size: 30">Page list</h2>

  <div>
    <button type="button" class="btn-default" onclick="main_page()">Back to main page</button>
  </div>
  <div>
    <?php
    if (isset($_GET['del'])) {
      $del = $_GET['del'];
      if ($del == '1') {
        echo '<p style="font-weight: bold; color: #008000">Page was deleted from the TAB</p>';
      } else {
        echo '<p style="font-weight: bold; color: red">Page was not deleted from the TAB</p>';
      }
    }
    ?>
  </div>
  <div class="CSSTableGenerator">
    <table style="table-layout: fixed; width: 100%">
      <tr>
        <td style="width: 200px;">page name</td>
        <td>Page URL</td>
        <td class="center">TAB number</td>
        <td class="center">Delete</td>
      </tr>
      <?php while ($row = mysql_fetch_assoc($results)) {
        ?>
        <tr>
          <td style="width: 200px;">
            <?php echo $row['page_name'] ?>
          </td>
          <td style="word-wrap: break-word">
            <?php echo $row['url'] ?>
          </td>
          <td class="center">
            <?php echo $row['tab_id'] ?>
          </td>
          <td class="center">
            <a href="#" onclick="func_delete(<?php echo $row['id']; ?>)"><img src="../images/delete.png"
                                                                              style="height: 25px;width: 25px"></a>
          </td>
        </tr>
      <?php } ?>
    </table>
  </div>

</div>
</body>
</html>
